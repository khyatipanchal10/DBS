-- ***********************
-- Name: Khyati Panchal
-- ID: 132297169
-- Date: May 16,2017
-- Purpose: Demonstrates the use ofSelect Statement along with the ORDER BY statement.
-- ***********************


select * from employees;

-- Q1:Display the employee_id, last name and salary of employees earning 
-- in the range of $8,000 to $15,000.  
-- Sort the output by top salaries first and then by last name.

select 
    employee_id AS "EMPLOYEE_ID",
    last_name AS "LAST_NAME",
    salary AS "SALARY" 
    FROM EMPLOYEES 
    WHERE 
        SALARY >=8000 and SALARY<= 15000 
    ORDER BY salary DESC;
    
-- Q2:Modify previous query (#1) so that additional condition is 
-- to display only if they work as Programmers or Sales Representatives. 
-- Use same sorting as before.

select
    employee_id AS "EMPLOYEE_ID",
    last_name AS "LAST_NAME",
    salary AS "SALARY"
    FROM EMPLOYEES
    WHERE 
        ((SALARY>=8000 and SALARY<=15000) AND
        (JOB_ID='IT_PROG' OR JOB_ID='SA_REP'))
    ORDER BY SALARY DESC;
    
-- Q3:The Human Resources department wants to find high salary and low salary employees. 
-- Modify previous query (#2) so that it displays the same job titles but for people who earn 
-- outside the given salary range from question 1. 
-- Use same sorting as before.

select
    employee_id AS "EMPLOYEE_ID",
    last_name AS "LAST_NAME",
    salary AS "SALARY",
    job_id AS "JOB_ID"
    FROM EMPLOYEES
    WHERE 
        (SALARY < 8000 OR salary > 15000)AND
        (upper(JOB_ID)=upper('IT_PROG') OR upper(JOB_ID)= upper('SA_REP'))
    ORDER BY SALARY desc;
    
-- Q4:The company needs a list of long term employees, in order to give them a thank you dinner. 
-- Display the last name, job_id and salary of employees hired before 1998.
-- List the most recently hired employees first.
    
select
    employee_id AS "EMPLOYEE_ID",
    last_name AS "LAST_NAME",
    salary AS "SALARY",
    job_id AS "JOB_ID",
    hire_date AS "HIRE_DATE"
    FROM EMPLOYEES
    WHERE 
        (HIRE_DATE<='1-Jan-98')
    ORDER BY HIRE_DATE DESC;
    
-- Q5.Modify previous query (#4) so that it displays only employees earning more than $10,000. 
-- List the output by job title alphabetically and then by highest paid employees.
    
select
    last_name AS "LAST_NAME",
    job_id AS "JOB_ID",
     salary AS "SALARY"
    FROM EMPLOYEES
    WHERE 
        SALARY > 10000 and HIRE_DATE < '1-Jan-98'
    ORDER BY JOB_ID, SALARY DESC;
    
-- Q6:Display the job titles and full names of employees whose first name contains an �e� or �E� anywhere.
    
select
    job_id AS "JOB_ID",
    first_name || ' ' || last_name AS "FULL_NAME"    
    FROM EMPLOYEES
    WHERE 
        FIRST_NAME LIKE '%e%' OR FIRST_NAME LIKE '%E%';
    ORDER BY JOB_ID ASC,FIRST_NAME DESC;
    
    
-- Q7:Create a report to display last name, salary, and commission percent for all employees that earn a commission.
    
select    
    last_name AS "LAST_NAME",
    salary AS "SALARY",
    commission_pct AS "COMMISSION_PCT"
    FROM EMPLOYEES
    WHERE 
        COMMISSION_PCT !=0.0;
    
    
-- Q8:Do the same as question 7, but put the report in order of descending salaries.
    
select    
    last_name AS "LAST_NAME",
    salary AS "SALARY",
    commission_pct AS "COMMISSION_PCT"
    FROM EMPLOYEES
    WHERE 
        COMMISSION_PCT !=0.0
    ORDER BY SALARY DESC;
    
    
-- Q9:Do the same as 8, but use a numeric value instead of a column name to do the sorting.
    
select    
    last_name AS "LAST_NAME",
    SALARY AS "SALARY",
    commission_pct AS "COMMISSION_PCT"
    FROM EMPLOYEES
    WHERE 
        COMMISSION_PCT !=0.0
    ORDER BY 2 DESC;